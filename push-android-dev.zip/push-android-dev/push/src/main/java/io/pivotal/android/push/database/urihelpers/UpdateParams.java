package io.pivotal.android.push.database.urihelpers;

import android.net.Uri;

public class UpdateParams {
	public Uri uri;
	public String whereClause;
	public String[] whereArgs;
}
