package io.pivotal.android.push.database.urihelpers;

public class UriMatcherParams {
	public String authority;
	public String path;
}
