package io.pivotal.android.push.analytics.jobs;

public interface Job {

    void run(JobParams jobParams);
}
