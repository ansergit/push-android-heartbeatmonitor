package io.pivotal.android.push.database.urihelpers;

import android.net.Uri;

public class QueryParams {
	public Uri uri;
	public String[] projection;
	public String whereClause;
	public String[] whereArgs;
	public String sortOrder;
}
