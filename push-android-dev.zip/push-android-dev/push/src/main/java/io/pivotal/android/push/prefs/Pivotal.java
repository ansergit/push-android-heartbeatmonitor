/*
 * Copyright (C) 2014 Pivotal Software, Inc. All rights reserved.
 */
package io.pivotal.android.push.prefs;

public class Pivotal {
    public enum SslCertValidationMode {
        DEFAULT,
        TRUST_ALL,
        PINNED,
        CALLBACK
    }
}
