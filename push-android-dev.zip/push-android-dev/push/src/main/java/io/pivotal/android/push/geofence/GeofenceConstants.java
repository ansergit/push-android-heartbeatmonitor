package io.pivotal.android.push.geofence;

public class GeofenceConstants {

    public static final long NEVER_UPDATED_GEOFENCES = -1L;
}
