Dependencies
============

Name                    | Version | Description                          | License           | License Text | URL                                                           | Modified | Interaction
----------------------- | ------- | ------------------------------------ | ----------------- | ------------ | ------------------------------------------------------------- | -------- | ------------------------------------
gson                    | 2.4.0   |                                      | Apache2.0         |              | https://code.google.com/p/google-gson                         | NO       | Dynamically linked. Not distributed.
Google Play Services    | 8.1.0   |                                      | AndroidSDKLicense |              | https://developers.google.com/android/guides/overview         | NO       | Dynamically linked. Not distributed.
Android Support Library | 23.1.1  |                                      | AndroidSDKLicense |              | https://developer.android.com/topic/libraries/support-library | NO       | Dynamically linked. Not distributed.
